Nika CRM

Открывать на iPhone нужно не как скачанный HTML-файл, а как сайт через Safari.

Быстрый запуск:
1. Зайти на netlify.com/drop
2. Перетащить всю папку nika-crm-netlify или ZIP
3. Получить ссылку вида https://...netlify.app
4. Открыть эту ссылку в Safari на iPhone

Если открывать HTML через Telegram/WhatsApp/Files/ChatGPT preview, iPhone может не запускать JavaScript — кнопки будут не работать.
